name = "Test Mod 2 ";
dir = "@testmod2";
author = "Test User";
description = "Mod for testing";