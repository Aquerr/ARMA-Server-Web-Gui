protocol = 1;
publishedid = 123456782;
name = "Test Mod 2";
timestamp = 5249164434284801218;
