name = "Test Mod";
dir = "@testmod";
author = "Test User";
description = "Mod for testing";