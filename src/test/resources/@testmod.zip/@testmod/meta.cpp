protocol = 1;
publishedid = 123456789;
name = "Test Mod";
timestamp = 5249164434284801218;
